package com.tenzo.api;

import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
public class BookingService {
    private final ServiceCatalog catalog;
    private final Map<UUID, Booking> bookings = new ConcurrentHashMap<>();

    public BookingService(ServiceCatalog catalog) {
        this.catalog = catalog;
    }

    public Booking create(CreateBookingRequest request) {
        ServiceCatalog.HomeService service = catalog.findService(request.serviceId())
            .orElseThrow(() -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "Unknown service id"));
        ServiceCatalog.Helper helper = catalog.findHelper(request.helperName())
            .orElseThrow(() -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "Unknown helper name"));

        Booking booking = new Booking(
            UUID.randomUUID(), service.id(), service.name(), helper.name(),
            request.date(), request.time(), service.price(), "confirmed"
        );
        bookings.put(booking.id(), booking);
        return booking;
    }

    public List<Booking> findAll() {
        return bookings.values().stream()
            .sorted(Comparator.comparing(Booking::date).thenComparing(Booking::time))
            .toList();
    }

    public record CreateBookingRequest(String serviceId, String helperName, java.time.LocalDate date, String time) {}

    public record Booking(UUID id, String serviceId, String serviceName, String helperName,
                          java.time.LocalDate date, String time, int price, String status) {}
}
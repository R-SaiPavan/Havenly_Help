package com.tenzo.api;

import java.util.List;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class ServiceController {
    private final ServiceCatalog catalog;

    public ServiceController(ServiceCatalog catalog) {
        this.catalog = catalog;
    }

    @GetMapping("/services")
    public List<ServiceCatalog.HomeService> services() {
        return catalog.services();
    }

    @GetMapping("/helpers")
    public List<ServiceCatalog.Helper> helpers() {
        return catalog.helpers();
    }
}

package com.tenzo.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TenzoApplication {
    public static void main(String[] args) {
        SpringApplication.run(TenzoApplication.class, args);
    }
}

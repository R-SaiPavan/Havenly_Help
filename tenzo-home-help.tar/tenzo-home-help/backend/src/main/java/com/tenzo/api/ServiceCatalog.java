package com.tenzo.api;

import java.util.List;
import java.util.Optional;
import org.springframework.stereotype.Component;

@Component
public class ServiceCatalog {
    private final List<HomeService> services = List.of(
        new HomeService("home-reset", "Home reset", "A fresh, calm home", 32, "from", "✦"),
        new HomeService("deep-clean", "Deep clean", "The full refresh", 48, "from", "✧"),
        new HomeService("meal-prep", "Meal prep", "Dinner, handled", 28, "from", "◒"),
        new HomeService("laundry", "Laundry", "Folded and ready", 22, "from", "⌁")
    );

    private final List<Helper> helpers = List.of(
        new Helper("Maya R.", "Top-rated home care", "4.9", "Arrives in 25 min", "coral", "MR"),
        new Helper("Nia S.", "Clean & organized", "4.8", "Arrives in 40 min", "sage", "NS"),
        new Helper("Ava K.", "Kitchen specialist", "4.9", "Available at 2:30 PM", "yellow", "AK")
    );

    public List<HomeService> services() {
        return services;
    }

    public List<Helper> helpers() {
        return helpers;
    }

    public Optional<HomeService> findService(String id) {
        return services.stream().filter(service -> service.id().equals(id)).findFirst();
    }

    public Optional<Helper> findHelper(String name) {
        return helpers.stream().filter(helper -> helper.name().equals(name)).findFirst();
    }

    public record HomeService(String id, String name, String subtitle, int price, String priceLabel, String symbol) {}

    public record Helper(String name, String detail, String rating, String eta, String tone, String initials) {}
}
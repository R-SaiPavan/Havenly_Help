package com.tenzo.api;

import jakarta.validation.Valid;
import jakarta.validation.constraints.FutureOrPresent;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import java.time.LocalDate;
import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/bookings")
public class BookingController {
    private final BookingService bookingService;

    public BookingController(BookingService bookingService) {
        this.bookingService = bookingService;
    }

    @GetMapping
    public List<BookingService.Booking> bookings() {
        return bookingService.findAll();
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public BookingService.Booking createBooking(@Valid @RequestBody CreateBookingRequest request) {
        return bookingService.create(new BookingService.CreateBookingRequest(
            request.serviceId(), request.helperName(), request.date(), request.time()
        ));
    }

    public record CreateBookingRequest(
        @NotBlank String serviceId,
        @NotBlank String helperName,
        @NotNull @FutureOrPresent LocalDate date,
        @NotBlank @Pattern(regexp = "9:00 AM|11:30 AM|2:30 PM|4:00 PM") String time
    ) {}
}
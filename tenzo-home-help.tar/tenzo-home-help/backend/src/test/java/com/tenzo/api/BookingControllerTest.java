package com.tenzo.api;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;

import java.time.LocalDate;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

@SpringBootTest
@AutoConfigureMockMvc
class BookingControllerTest {
    @Autowired
    private MockMvc mockMvc;

    @Test
    void servesFrontendFromRootAndStaticAssets() throws Exception {
        mockMvc.perform(get("/"))
            .andExpect(status().isOk());

        mockMvc.perform(get("/index.html"))
            .andExpect(status().isOk())
            .andExpect(content().string(org.hamcrest.Matchers.containsString("Havenly Help")));

        mockMvc.perform(get("/app.css"))
            .andExpect(status().isOk());

        mockMvc.perform(get("/app.js"))
            .andExpect(status().isOk());

        mockMvc.perform(get("/login.html"))
            .andExpect(status().isOk())
            .andExpect(content().string(org.hamcrest.Matchers.containsString("Sign in")))
            .andExpect(content().string(org.hamcrest.Matchers.containsString("./signup.html")));

        mockMvc.perform(get("/signup.html"))
            .andExpect(status().isOk())
            .andExpect(content().string(org.hamcrest.Matchers.containsString("Create your account")))
            .andExpect(content().string(org.hamcrest.Matchers.containsString("./login.html")));

        mockMvc.perform(get("/auth.css"))
            .andExpect(status().isOk());

        mockMvc.perform(get("/auth.js"))
            .andExpect(status().isOk());

        mockMvc.perform(get("/manifest.webmanifest"))
            .andExpect(status().isOk())
            .andExpect(content().string(org.hamcrest.Matchers.containsString("\"display\": \"standalone\"")));

        mockMvc.perform(get("/service-worker.js"))
            .andExpect(status().isOk())
            .andExpect(content().string(org.hamcrest.Matchers.containsString("/api/")));

        mockMvc.perform(get("/pwa.js"))
            .andExpect(status().isOk());

        mockMvc.perform(get("/icon-192.png"))
            .andExpect(status().isOk());

        mockMvc.perform(get("/icon-512.png"))
            .andExpect(status().isOk());

        mockMvc.perform(get("/favicon.svg"))
            .andExpect(status().isOk())
            .andExpect(content().string(org.hamcrest.Matchers.containsString(">H</text>")));
    }

    @Test
    void createsAndListsBooking() throws Exception {
        String booking = """
            {
              "serviceId": "deep-clean",
              "helperName": "Nia S.",
              "date": "%s",
              "time": "11:30 AM"
            }
            """.formatted(LocalDate.now().plusDays(1));

        mockMvc.perform(post("/api/bookings")
                .contentType(MediaType.APPLICATION_JSON)
                .content(booking))
            .andExpect(status().isCreated())
            .andExpect(jsonPath("$.id").isNotEmpty())
            .andExpect(jsonPath("$.serviceName").value("Deep clean"))
            .andExpect(jsonPath("$.helperName").value("Nia S."))
            .andExpect(jsonPath("$.price").value(48))
            .andExpect(jsonPath("$.status").value("confirmed"));

        mockMvc.perform(get("/api/bookings"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$[0].serviceId").value("deep-clean"));
    }

    @Test
    void rejectsUnknownService() throws Exception {
        String booking = """
            {
              "serviceId": "unknown",
              "helperName": "Nia S.",
              "date": "%s",
              "time": "11:30 AM"
            }
            """.formatted(LocalDate.now().plusDays(1));

        mockMvc.perform(post("/api/bookings")
                .contentType(MediaType.APPLICATION_JSON)
                .content(booking))
            .andExpect(status().isBadRequest());
    }

    @Test
    void rejectsPastBookingDate() throws Exception {
        String booking = """
            {
              "serviceId": "deep-clean",
              "helperName": "Nia S.",
              "date": "%s",
              "time": "11:30 AM"
            }
            """.formatted(LocalDate.now().minusDays(1));

        mockMvc.perform(post("/api/bookings")
                .contentType(MediaType.APPLICATION_JSON)
                .content(booking))
            .andExpect(status().isBadRequest());
    }
}

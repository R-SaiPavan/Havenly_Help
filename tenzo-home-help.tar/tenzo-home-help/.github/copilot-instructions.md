# Tenzo Home Help

- Frontend: React, Vite, TypeScript, Tailwind CSS, PWA.
- Backend: Spring Boot REST API on Java 21 with Maven.
- Keep booking flows mobile-first, accessible, and focused on fast household-service scheduling.
- Run frontend commands from `frontend/` and backend commands from `backend/`.

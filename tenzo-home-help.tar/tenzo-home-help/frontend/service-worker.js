const CACHE_PREFIX = 'havenly-help-app-shell-'
const CACHE_NAME = `${CACHE_PREFIX}v1`
const LEGACY_CACHE_NAMES = ['tenzo-app-shell-v1']
const APP_SHELL = [
  '/',
  '/index.html',
  '/login.html',
  '/signup.html',
  '/app.css',
  '/app.js',
  '/auth.css',
  '/auth.js',
  '/manifest.webmanifest',
  '/favicon.svg',
  '/pwa.js',
  '/icon-192.png',
  '/icon-512.png',
  '/apple-touch-icon.png'
]

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => cache.addAll(APP_SHELL))
      .then(() => self.skipWaiting())
  )
})

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys
        .filter((key) => (key.startsWith(CACHE_PREFIX) && key !== CACHE_NAME) || LEGACY_CACHE_NAMES.includes(key))
        .map((key) => caches.delete(key))))
      .then(() => self.clients.claim())
  )
})

self.addEventListener('fetch', (event) => {
  const request = event.request
  const url = new URL(request.url)
  if (request.method !== 'GET' || url.origin !== self.location.origin || url.pathname.startsWith('/api/')) return

  if (request.mode === 'navigate') {
    event.respondWith(fetch(request).then(async (response) => {
      if (response.ok) {
        await caches.open(CACHE_NAME).then((cache) => cache.put(request, response.clone()))
      }
      return response
    }).catch(async () => {
      return await caches.match(request) || await caches.match('/index.html')
    }))
    return
  }

  event.respondWith(caches.match(request).then((cached) => {
    if (cached) return cached
    return fetch(request).then(async (response) => {
      if (response.ok) {
        await caches.open(CACHE_NAME).then((cache) => cache.put(request, response.clone()))
      }
      return response
    })
  }))
})

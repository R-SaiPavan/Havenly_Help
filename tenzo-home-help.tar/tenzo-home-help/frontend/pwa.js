if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/service-worker.js').catch((error) => {
      console.error('Havenly Help offline support could not be started:', error)
    })
  })
}

let installPrompt
window.addEventListener('beforeinstallprompt', (event) => {
  event.preventDefault()
  installPrompt = event

  if (document.querySelector('.pwa-install-button')) return
  const button = document.createElement('button')
  button.className = 'pwa-install-button'
  button.type = 'button'
  button.textContent = 'Install Havenly'
  button.addEventListener('click', async () => {
    if (!installPrompt) return
    installPrompt.prompt()
    await installPrompt.userChoice
    installPrompt = null
    button.remove()
  })
  document.body.append(button)
})

window.addEventListener('appinstalled', () => {
  document.querySelector('.pwa-install-button')?.remove()
  installPrompt = null
})

document.querySelectorAll('[data-password-toggle]').forEach((button) => {
  button.addEventListener('click', () => {
    const passwordInput = button.parentElement.querySelector('input')
    const showing = passwordInput.type === 'text'
    passwordInput.type = showing ? 'password' : 'text'
    button.textContent = showing ? 'Show' : 'Hide'
    button.setAttribute('aria-label', showing ? 'Show password' : 'Hide password')
  })
})

document.querySelectorAll('[data-auth-form]').forEach((form) => {
  form.addEventListener('submit', (event) => {
    event.preventDefault()
    const notice = form.querySelector('.auth-notice')
    notice.textContent = 'Account access is not connected yet. Your details were not sent or saved.'
    notice.hidden = false
  })
})

document.querySelectorAll('[data-inert-link]').forEach((link) => {
  link.addEventListener('click', (event) => event.preventDefault())
})

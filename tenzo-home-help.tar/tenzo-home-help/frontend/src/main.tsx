import { StrictMode, useState } from 'react'
import { createRoot } from 'react-dom/client'
import { ArrowRight, Bell, CalendarDays, Check, ChevronDown, Clock3, Home, MapPin, Menu, Plus, Search, ShieldCheck, Sparkles, Star, UserRound, X } from 'lucide-react'
import './styles.css'

type Service = { id: string; name: string; subtitle: string; price: number; symbol: string }
const services: Service[] = [
  { id: 'home-reset', name: 'Home reset', subtitle: 'A fresh, calm home', price: 32, symbol: '✦' },
  { id: 'deep-clean', name: 'Deep clean', subtitle: 'The full refresh', price: 48, symbol: '✧' },
  { id: 'meal-prep', name: 'Meal prep', subtitle: 'Dinner, handled', price: 28, symbol: '◒' },
  { id: 'laundry', name: 'Laundry', subtitle: 'Folded and ready', price: 22, symbol: '⌁' }
]
const helpers = [
  { name: 'Maya R.', detail: 'Top-rated home care', rating: '4.9', eta: 'Arrives in 25 min', tone: 'coral', initials: 'MR' },
  { name: 'Nia S.', detail: 'Clean & organized', rating: '4.8', eta: 'Arrives in 40 min', tone: 'sage', initials: 'NS' },
  { name: 'Ava K.', detail: 'Kitchen specialist', rating: '4.9', eta: 'Available at 2:30 PM', tone: 'yellow', initials: 'AK' }
]

function App() {
  const [selectedService, setSelectedService] = useState(services[0])
  const [selectedHelper, setSelectedHelper] = useState(helpers[0])
  const [showBooking, setShowBooking] = useState(false)
  const [mobileMenu, setMobileMenu] = useState(false)

  return <div className="min-h-screen bg-cream text-ink">
    <header className="border-b border-ink/10 bg-cream/90 backdrop-blur sticky top-0 z-20">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-5 py-4 lg:px-10">
        <a className="flex items-center gap-2" href="#top"><span className="brand-mark">H</span><span className="font-display text-2xl font-semibold tracking-tight">Havenly Help</span></a>
        <nav className="hidden items-center gap-8 text-sm font-semibold text-ink/65 md:flex"><a className="text-ink" href="#book">Book help</a><a href="#how-it-works">How it works</a><a href="#bookings">My bookings</a></nav>
        <div className="flex items-center gap-3"><button className="icon-button hidden sm:flex" aria-label="Notifications"><Bell size={18}/><span className="notification-dot"/></button><button className="profile-button"><span>JR</span><ChevronDown size={15}/></button><button className="icon-button md:hidden" aria-label="Menu" onClick={() => setMobileMenu(!mobileMenu)}>{mobileMenu ? <X size={19}/> : <Menu size={19}/>}</button></div>
      </div>
      {mobileMenu && <nav className="border-t border-ink/10 px-5 py-4 md:hidden"><a className="block py-2 font-semibold" href="#book">Book help</a><a className="block py-2 font-semibold text-ink/60" href="#how-it-works">How it works</a><a className="block py-2 font-semibold text-ink/60" href="#bookings">My bookings</a></nav>}
    </header>

    <main id="top" className="mx-auto max-w-7xl px-5 pb-20 lg:px-10">
      <section className="hero-grid py-12 lg:py-20"><div className="max-w-2xl reveal"><p className="eyebrow"><span className="eyebrow-line"/> HOUSE HELP, ON YOUR TERMS</p><h1 className="font-display text-5xl leading-[.98] tracking-[-.04em] sm:text-7xl">A little help<br/><em>goes a long way.</em></h1><p className="mt-7 max-w-lg text-lg leading-8 text-ink/65">Trusted people for the things that keep your home and life moving. Book in minutes, feel the difference all week.</p><a className="primary-button mt-9 inline-flex" href="#book">Find your help <ArrowRight size={18}/></a></div><div className="hero-art reveal-delay"><div className="sun-shape"/><div className="hero-card"><div className="hero-card-top"><span className="small-label">TODAY'S LITTLE WIN</span><span className="spark"><Sparkles size={16}/></span></div><div className="plant"><div className="plant-stem"/><span className="leaf leaf-one"/><span className="leaf leaf-two"/><span className="leaf leaf-three"/><span className="pot"/></div><div className="hero-note"><span className="check-circle"><Check size={14}/></span><span>Home reset, done</span><span className="text-ink/40">9:42 AM</span></div></div><div className="floating-stamp"><ShieldCheck size={17}/><span>Vetted helpers</span></div></div></section>

      <section id="book" className="booking-section"><div className="section-heading"><div><p className="eyebrow"><span className="eyebrow-line"/> START HERE</p><h2 className="font-display text-4xl tracking-[-.03em] sm:text-5xl">What can we take<br className="hidden sm:block"/> off your plate?</h2></div><div className="address-pill"><MapPin size={17}/><span>Brooklyn, NY</span><ChevronDown size={15}/></div></div><div className="service-grid">{services.map((service) => <button key={service.id} className={`service-card ${selectedService.id === service.id ? 'selected' : ''}`} onClick={() => setSelectedService(service)}><span className="service-symbol">{service.symbol}</span><span className="mt-7 block text-left font-semibold">{service.name}</span><span className="mt-1 block text-left text-sm text-ink/50">{service.subtitle}</span><span className="mt-5 flex items-center justify-between text-left text-sm"><span className="text-ink/50">{service.price} <small>/ hour</small></span><span className="round-arrow"><ArrowRight size={15}/></span></span></button>)}</div></section>

      <section id="how-it-works" className="helpers-section"><div className="section-heading"><div><p className="eyebrow"><span className="eyebrow-line"/> PEOPLE YOU CAN COUNT ON</p><h2 className="font-display text-4xl tracking-[-.03em] sm:text-5xl">Meet your next<br className="hidden sm:block"/> favorite helper.</h2></div><button className="text-button hidden sm:flex">See all helpers <ArrowRight size={17}/></button></div><div className="helper-grid">{helpers.map((helper) => <button key={helper.name} className={`helper-card ${selectedHelper.name === helper.name ? 'active' : ''}`} onClick={() => setSelectedHelper(helper)}><div className={`helper-avatar ${helper.tone}`}><span>{helper.initials}</span><span className="available-dot"/></div><div className="flex-1 text-left"><div className="flex items-center justify-between gap-2"><strong>{helper.name}</strong><span className="rating"><Star size={13} fill="currentColor"/> {helper.rating}</span></div><p className="mt-1 text-sm text-ink/50">{helper.detail}</p><p className="mt-4 flex items-center gap-1.5 text-xs font-semibold text-ink/65"><Clock3 size={13}/>{helper.eta}</p></div><span className="helper-select"><Check size={14}/></span></button>)}</div></section>

      <section id="bookings" className="trust-strip"><div><p className="eyebrow"><span className="eyebrow-line"/> THE HAVENLY PROMISE</p><h2 className="font-display mt-4 text-3xl tracking-[-.03em] sm:text-4xl">More time for what matters.</h2></div><div className="trust-items"><div><ShieldCheck size={22}/><span>Every helper<br/><b>vetted & verified</b></span></div><div><CalendarDays size={22}/><span>Book today,<br/><b>change anytime</b></span></div><div><Sparkles size={22}/><span>Support that<br/><b>has your back</b></span></div></div></section>
    </main>

    {showBooking && <div className="modal-backdrop" onClick={() => setShowBooking(false)}><div className="booking-modal" onClick={(event) => event.stopPropagation()}><button className="modal-close" aria-label="Close" onClick={() => setShowBooking(false)}><X size={18}/></button><div className="modal-icon"><Check size={22}/></div><p className="eyebrow">READY WHEN YOU ARE</p><h2 className="font-display mt-3 text-4xl">Book {selectedService.name}.</h2><p className="mt-3 text-ink/60">{selectedHelper.name} is your selected helper. Choose a time and we’ll take it from there.</p><div className="modal-field"><CalendarDays size={17}/><span>Today, 2:30 PM</span><ChevronDown size={15}/></div><button className="primary-button mt-5 w-full justify-center" onClick={() => setShowBooking(false)}>Confirm booking <ArrowRight size={18}/></button></div></div>}
    <button className="floating-book" onClick={() => setShowBooking(true)}><Plus size={18}/> Book now</button>
  </div>
}

createRoot(document.getElementById('root')!).render(<StrictMode><App /></StrictMode>)

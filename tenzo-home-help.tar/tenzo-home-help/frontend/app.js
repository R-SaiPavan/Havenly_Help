const services = [
  { id: 'home-reset', name: 'Home reset', subtitle: 'A fresh, calm home', price: 32, symbol: '✦', tone: 'coral' },
  { id: 'deep-clean', name: 'Deep clean', subtitle: 'The full refresh', price: 48, symbol: '✧', tone: 'sage' },
  { id: 'meal-prep', name: 'Meal prep', subtitle: 'Dinner, handled', price: 28, symbol: '◒', tone: 'peach' },
  { id: 'laundry', name: 'Laundry', subtitle: 'Folded and ready', price: 22, symbol: '⌁', tone: 'blue' }
]
const helpers = [
  { name: 'Maya R.', detail: 'Top-rated home care', rating: '4.9', eta: 'Arrives in 25 min', initials: 'MR', tone: 'coral' },
  { name: 'Nia S.', detail: 'Clean & organized', rating: '4.8', eta: 'Arrives in 40 min', initials: 'NS', tone: 'sage' },
  { name: 'Ava K.', detail: 'Kitchen specialist', rating: '4.9', eta: 'Available at 2:30 PM', initials: 'AK', tone: 'yellow' }
]

let selectedService = services[0]
let selectedHelper = helpers[0]
const serviceList = document.querySelector('#service-list')
const helperList = document.querySelector('#helper-list')
const bookingModal = document.querySelector('#booking-modal')
const initialBookingContent = bookingModal.innerHTML
const menuToggle = document.querySelector('.menu-toggle')
const mobileNav = document.querySelector('#mobile-nav')

function renderServices() {
  serviceList.innerHTML = services.map((service) => `
    <button class="service-card ${service.id === selectedService.id ? 'selected' : ''}" type="button" data-service="${service.id}" aria-pressed="${service.id === selectedService.id}">
      <span class="service-symbol ${service.tone}" aria-hidden="true">${service.symbol}</span><strong>${service.name}</strong><span class="service-subtitle">${service.subtitle}</span>
      <span class="service-bottom"><span>$${service.price} <small>/ hour</small></span><span class="round-arrow" aria-hidden="true">&#8594;</span></span>
    </button>`).join('')
}

function renderHelpers() {
  helperList.innerHTML = helpers.map((helper) => `
    <button class="helper-card ${helper.name === selectedHelper.name ? 'active' : ''}" type="button" data-helper="${helper.name}" aria-pressed="${helper.name === selectedHelper.name}">
      <span class="helper-avatar ${helper.tone}">${helper.initials}<span class="online-dot"></span></span>
      <span class="helper-info"><span class="helper-topline"><strong>${helper.name}</strong><span class="rating"><span aria-hidden="true">&#9733;</span> ${helper.rating}</span></span><span class="helper-detail">${helper.detail}</span><span class="helper-eta"><span aria-hidden="true">&#9719;</span> ${helper.eta}</span></span><span class="helper-select" aria-hidden="true">&#10003;</span>
    </button>`).join('')
}

async function loadCatalog() {
  try {
    const [serviceResponse, helperResponse] = await Promise.all([
      fetch('/api/services'),
      fetch('/api/helpers')
    ])
    if (!serviceResponse.ok || !helperResponse.ok) throw new Error('Could not load booking options.')
    services.splice(0, services.length, ...await serviceResponse.json())
    helpers.splice(0, helpers.length, ...await helperResponse.json())
    selectedService = services[0]
    selectedHelper = helpers[0]
    renderServices()
    renderHelpers()
  } catch (error) {
    console.error('Using offline demo catalog:', error)
  }
}

function openBooking() {
  if (!bookingModal.querySelector('#booking-form')) bookingModal.innerHTML = initialBookingContent
  document.querySelector('#modal-title').textContent = `Book ${selectedService.name}.`
  document.querySelector('#modal-description').textContent = `${selectedHelper.name} is your selected helper. Choose a day and time to request your booking.`
  const dateInput = document.querySelector('#booking-date')
  const today = new Date()
  const localToday = new Date(today.getTime() - today.getTimezoneOffset() * 60000).toISOString().slice(0, 10)
  dateInput.min = localToday
  if (!dateInput.value) dateInput.value = localToday
  bookingModal.hidden = false
  document.body.classList.add('modal-open')
  dateInput.focus()
}

function closeBooking() {
  bookingModal.hidden = true
  document.body.classList.remove('modal-open')
  document.querySelector('[data-open-booking]').focus()
}

serviceList.addEventListener('click', (event) => {
  const card = event.target.closest('[data-service]')
  if (!card) return
  selectedService = services.find((service) => service.id === card.dataset.service)
  renderServices()
})
helperList.addEventListener('click', (event) => {
  const card = event.target.closest('[data-helper]')
  if (!card) return
  selectedHelper = helpers.find((helper) => helper.name === card.dataset.helper)
  renderHelpers()
})
document.querySelectorAll('[data-open-booking]').forEach((button) => button.addEventListener('click', openBooking))
bookingModal.addEventListener('click', (event) => {
  if (event.target === bookingModal || event.target.closest('.modal-close, .done-button')) closeBooking()
})
document.addEventListener('keydown', (event) => { if (event.key === 'Escape' && !bookingModal.hidden) closeBooking() })

bookingModal.addEventListener('submit', (event) => {
  if (event.target.id !== 'booking-form') return
  event.preventDefault()
  submitBooking(event.target)
})

async function submitBooking(form) {
  const submitButton = form.querySelector('[type="submit"]')
  submitButton.disabled = true
  submitButton.textContent = 'Sending request...'
  const data = new FormData(form)
  const request = {
    serviceId: selectedService.id,
    helperName: selectedHelper.name,
    date: data.get('date'),
    time: data.get('time')
  }
  const modal = document.querySelector('.booking-modal')
  try {
    const response = await fetch('/api/bookings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(request)
    })
    const result = await response.json()
    if (!response.ok) throw new Error(result.detail || result.message || 'We could not create that booking.')
    const date = new Date(`${result.date}T12:00:00`).toLocaleDateString(undefined, { weekday: 'long', month: 'long', day: 'numeric' })
    modal.innerHTML = `<button class="modal-close" type="button" aria-label="Close booking dialog">&#10005;</button><div class="modal-mark" aria-hidden="true">&#10003;</div><p class="eyebrow"><span></span> BOOKING CONFIRMED</p><h2 id="modal-title">You're all set.</h2><p id="modal-description" class="modal-description">Your ${result.serviceName.toLowerCase()} with ${result.helperName} is booked for ${date} at ${result.time}. Booking reference: ${result.id.slice(0, 8)}.</p><button class="button button-dark confirm-button done-button" type="button">Back to Havenly Help <span aria-hidden="true">&#8594;</span></button>`
    modal.querySelector('.done-button').focus()
  } catch (error) {
    document.querySelector('#modal-description').textContent = error.message || 'The booking service is unavailable. Please try again.'
    submitButton.disabled = false
    submitButton.innerHTML = 'Confirm booking <span aria-hidden="true">&#8594;</span>'
  }
}

menuToggle.addEventListener('click', () => {
  const isOpen = menuToggle.getAttribute('aria-expanded') === 'true'
  menuToggle.setAttribute('aria-expanded', String(!isOpen))
  menuToggle.setAttribute('aria-label', isOpen ? 'Open menu' : 'Close menu')
  mobileNav.hidden = isOpen
})
mobileNav.addEventListener('click', (event) => {
  if (!event.target.closest('a')) return
  mobileNav.hidden = true
  menuToggle.setAttribute('aria-expanded', 'false')
  menuToggle.setAttribute('aria-label', 'Open menu')
})

renderServices()
renderHelpers()
loadCatalog()
